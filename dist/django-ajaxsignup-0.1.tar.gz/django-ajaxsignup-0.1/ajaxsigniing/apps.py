from django.apps import AppConfig


class AjaxsigniingConfig(AppConfig):
    name = 'ajaxsigniing'
